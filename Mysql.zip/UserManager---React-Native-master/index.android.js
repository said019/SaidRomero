import React, { Component } from 'react';
import { AppRegistry,View,Text,StyleSheet } from 'react-native';

import UsersManager from './pages/app';
AppRegistry.registerComponent('UsersManager', () => UsersManager);
